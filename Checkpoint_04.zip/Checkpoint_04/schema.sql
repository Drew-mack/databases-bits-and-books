PRAGMA foreign_keys = ON;

-- Publishing companies.
CREATE TABLE Publisher (
    PublisherID INTEGER PRIMARY KEY AUTOINCREMENT,
    Name VARCHAR(100) NOT NULL
);

-- Book catalog and current stock.
CREATE TABLE Book (
    ISBN VARCHAR(13) PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    PublicationYear INTEGER,
    StockQuantity INTEGER NOT NULL DEFAULT 0 CHECK (StockQuantity >= 0),
    Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    BPublisherID INTEGER NOT NULL,
    FOREIGN KEY (BPublisherID) REFERENCES Publisher(PublisherID)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Author names and optional biographies.
CREATE TABLE Author (
    AuthorID INTEGER PRIMARY KEY AUTOINCREMENT,
    Bio TEXT,
    FirstName VARCHAR(30) NOT NULL,
    MiddleName VARCHAR(100),
    LastName VARCHAR(30) NOT NULL
);

-- Catalog categories.
CREATE TABLE Category (
    CategoryID INTEGER PRIMARY KEY AUTOINCREMENT,
    CategoryName VARCHAR(30) NOT NULL,
    Description TEXT
);

-- Bookstore customers.
CREATE TABLE Customer (
    CustomerID INTEGER PRIMARY KEY AUTOINCREMENT,
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    Email VARCHAR(80) NOT NULL UNIQUE,
    Phone VARCHAR(20),
    Street VARCHAR(80),
    City VARCHAR(50),
    State VARCHAR(30),
    ZIPCode VARCHAR(10)
);

-- Employees who may process orders.
CREATE TABLE Employee (
    EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT,
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    Email VARCHAR(80) NOT NULL UNIQUE,
    Phone VARCHAR(20),
    Position VARCHAR(50),
    HourlyRate DECIMAL(8,2) CHECK (HourlyRate IS NULL OR HourlyRate >= 0)
);

-- Purchase headers; order price is derived from items.
CREATE TABLE Orders (
    OrderID INTEGER PRIMARY KEY AUTOINCREMENT,
    OrderDate DATE NOT NULL,
    PaymentMethod VARCHAR(30) NOT NULL
        CHECK (PaymentMethod IN ('Credit Card', 'Debit Card', 'Cash', 'Gift Card', 'PayPal')),
    OrderStatus VARCHAR(30) NOT NULL
        CHECK (OrderStatus IN ('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled')),
    OCustomerID INTEGER NOT NULL,
    OEmployeeID INTEGER,
    FOREIGN KEY (OCustomerID) REFERENCES Customer(CustomerID)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (OEmployeeID) REFERENCES Employee(EmployeeID)
        ON UPDATE CASCADE ON DELETE SET NULL
);

-- Books, quantities, and sale prices on each order.
CREATE TABLE Order_Item (
    OrderItemID INTEGER PRIMARY KEY AUTOINCREMENT,
    Quantity INTEGER NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(10,2) NOT NULL CHECK (UnitPrice >= 0),
    OOrderID INTEGER NOT NULL,
    OISBN VARCHAR(13) NOT NULL,
    FOREIGN KEY (OOrderID) REFERENCES Orders(OrderID)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (OISBN) REFERENCES Book(ISBN)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- One rating per customer and book.
CREATE TABLE BookRating (
    RatingID INTEGER PRIMARY KEY AUTOINCREMENT,
    Rating INTEGER NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    RISBN VARCHAR(13) NOT NULL,
    RCustomerID INTEGER NOT NULL,
    UNIQUE (RCustomerID, RISBN),
    FOREIGN KEY (RISBN) REFERENCES Book(ISBN)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (RCustomerID) REFERENCES Customer(CustomerID)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Many-to-many book-author links.
CREATE TABLE Writes (
    WISBN VARCHAR(13) NOT NULL,
    WAuthorID INTEGER NOT NULL,
    PRIMARY KEY (WISBN, WAuthorID),
    FOREIGN KEY (WISBN) REFERENCES Book(ISBN)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (WAuthorID) REFERENCES Author(AuthorID)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Many-to-many book-category links.
CREATE TABLE Is_In (
    IISBN VARCHAR(13) NOT NULL,
    ICategoryID INTEGER NOT NULL,
    PRIMARY KEY (IISBN, ICategoryID),
    FOREIGN KEY (IISBN) REFERENCES Book(ISBN)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (ICategoryID) REFERENCES Category(CategoryID)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- OrderPrice is derived, not stored. Example query:
-- SELECT OOrderID, SUM(Quantity * UnitPrice) AS OrderPrice
-- FROM Order_Item
-- GROUP BY OOrderID;
